#! /bin/sh

ln -s /usr/app/lib/modules  /lib/modules
cd /usr/app/lib/modules/2.6.32.2-FriendlyARM

if [ -f "modules.dep.bb" ]
then
echo "modules.dep.bb exists."
else
depmod
fi

#insmod ko

#COMM


#NFS
#insmod md5.ko
#insmod sunrpc.ko
#insmod lockd.ko 
#insmod cbc.ko
#insmod des_generic.ko
#insmod auth_rpcgss.ko 
#insmod nfs_acl.ko 
#insmod nfs.ko 
#insmod rpcsec_gss_krb5.ko


#MMC
#insmod mmc_core.ko;
#insmod mmc_block.ko;
#insmod s3cmci.ko;
modprobe s3cmci
modprobe mmc_block

#EXT4
#insmod crc16.ko
#insmod mbcache.ko;
#insmod jbd2.ko;
#insmod ext4.ko;
modprobe ext4

#fat
modprobe msdos
modprobe vfat

#ntfs
modprobe ntfs

#sound
modprobe snd-soc-s3c24xx-uda134x

#wireless
modprobe mac80211
modprobe lib80211

#char 
modprobe mini2440_buttons
modprobe mini2440_hello_module
modprobe mini2440_leds
modprobe mini2440_pwm
modprobe led-class

#rtc
modprobe rtc-s3c

echo "load modules Sucess!"

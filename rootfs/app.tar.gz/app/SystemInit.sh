#! /bin/sh

ifconfig eth0 192.168.2.230

#insmod ko
cd /usr/app/ko
#COMM


#NFS
insmod md5.ko
insmod sunrpc.ko
insmod lockd.ko 
insmod cbc.ko
insmod des_generic.ko
insmod auth_rpcgss.ko 
insmod nfs_acl.ko 
insmod nfs.ko 
insmod rpcsec_gss_krb5.ko


#MMC
insmod mmc_core.ko;
insmod mmc_block.ko;
insmod s3cmci.ko;

#EXT4
insmod crc16.ko
insmod mbcache.ko;
insmod jbd2.ko;
insmod ext4.ko;


#LINK SO
cd /usr/app/lib/

ln -s libanl-2.9.so           /lib/libanl.so.1
ln -s libBrokenLocale-2.9.so  /lib/libBrokenLocale.so.1
ln -s libcrypt-2.9.so         /lib/llibcrypt.so.1
ln -s libdl-2.9.so            /lib/libdl.so.2
ln -s libgcc_s.so.1           /lib/libgcc_s.so.1
ln -s libid3tag.so.0.3.0      /lib/libid3tag.so.0
ln -s libid3tag.so.0.3.0      /lib/libid3tag.so
ln -s libiw.so.29             /lib/libiw.so.29
ln -s libjpeg.so.62.0.0       /lib/libjpeg.so
ln -s libjpeg.so.62.0.0       /lib/libjpeg.so.62
ln -s libmad.so.0.2.1         /lib/libmad.so
ln -s libmad.so.0.2.1         /lib/libmad.so.0
ln -s libmemusage.so          /lib/libmemusage.so
ln -s libnsl-2.9.so           /lib/libnsl.so.1 
ln -s libnss_compat-2.9.so    /lib/libnss_compat.so.2
ln -s libnss_dns-2.9.so       /lib/libnss_dns.so.2
ln -s libnss_files-2.9.so     /lib/libnss_files.so.2
ln -s libnss_hesiod-2.9.so    /lib/libnss_hesiod.so.2 
ln -s libnss_nis-2.9.so       /lib/libnss_nis.so.2
ln -s libnss_nisplus-2.9.so   /lib/libnss_nisplus.so.2 
ln -s libpcprofile.so         /lib/libpcprofile.so 
ln -s libpng12.so.0.35.0      /lib/libpng12.so
ln -s libpng12.so.0.35.0      /lib/libpng12.so.0
ln -s libpng.so.3.35.0        /lib/libpng.so
ln -s libpng.so.3.35.0        /lib/libpng.so.3
ln -s libpthread-2.9.so       /lib/libpthread.so.0
ln -s libresolv-2.9.so        /lib/libresolv.so.2
ln -s librt-2.9.so            /lib/librt.so.1
ln -s libSegFault.so          /lib/libSegFault.so
ln -s libstdc++.so.6.0.13     /lib/libstdc++.so
ln -s libstdc++.so.6.0.13     /lib/libstdc++.so.6
ln -s libthread_db-1.0.so     /lib/libthread_db.so.1
ln -s libutil-2.9.so          /lib/libutil.so.1
ln -s libuuid.so              /lib/libuuid.so.1
ln -s libuuid.so              /lib/libuuid.so.1.2

#prepare
ln -s /usr/app/bin/hotplug     /bin/hotplug
ln -s /usb/app/bin/hotplug.sh  /bin/hotplug.sh
ln -s /usb/app/bin/led         /usr/bin/led
ln -s /usb/app/bin/led-player  /usr/bin/led-player
ln -s /usb/app/bin/boa         /usr/sbin/boa
ln -s /usb/app/bin/qt4         /bin/qt4
ln -s /usb/app/bin/qtopia      /bin/qtopia

#mini2440
/bin/mount -n -t usbfs none /proc/bus/usb
echo /sbin/mdev > /proc/sys/kernel/hotplug
/bin/hotplug

/sbin/hwclock -s
syslogd

/usr/app/etc/rc.d/init.d/netd start
echo "                        " > /dev/tty1
echo "Starting networking..." > /dev/tty1
sleep 1

/usr/app/etc/rc.d/init.d/httpd start
echo "                        " > /dev/tty1
echo "Starting web server..." > /dev/tty1
sleep 1

/usr/app/etc/rc.d/init.d/leds start
echo "                        " > /dev/tty1
echo "Starting leds service..." > /dev/tty1
echo "                        "
sleep 1


/bin/qtopia &
echo "                                  " > /dev/tty1
echo "Starting Qtopia, please waiting..." > /dev/tty1



mount -t jffs2 /dev/mtdblock4 /opt/
echo "mini2440 Start Sucess!"

#ifndef __kjavaappletcontext_h__
#define __kjavaappletcontext_h__

#include <qobject.h>

class KJavaAppletContext : public QObject
{
public:
    KJavaAppletContext() {};
};

#endif


#include "kdedmodule.h"

KDEDModule::KDEDModule( const QCString &name )
    : DCOPObject( name )
{
}

#include "kdedmodule.moc"


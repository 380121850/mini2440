#ifndef __keditcl_h__
#define __keditcl_h__

#include <qmultilineedit.h>

#define KEdit QMultiLineEdit

#endif

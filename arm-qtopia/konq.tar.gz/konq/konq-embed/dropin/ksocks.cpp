
#include "ksocks.h"

KSocks *KSocks::s_self = 0;
